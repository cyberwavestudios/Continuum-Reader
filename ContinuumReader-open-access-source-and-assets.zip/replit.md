# Workspace

## Overview

Continuum Digital Comic Reader — a mobile-optimized graphic novel reading experience for "Continuum Issue #1: Stay Alive or Die Trying" by Charlie Hadley. Built as a pnpm workspace monorepo using TypeScript.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Frontend**: React + Vite + Tailwind CSS + Framer Motion
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   ├── api-server/         # Express API server (comic API routes)
│   │   └── public/         # Pre-extracted comic page images + cover
│   │       ├── cover.jpg   # Cover art (converted from TIFF)
│   │       └── comic-pages/ # page-01.jpg through page-18.jpg
│   └── continuum-reader/   # React + Vite frontend (comic reader UI)
├── attached_assets/        # Original uploaded files
│   ├── Continuum_Compressed_File_Version_1773422710069.pdf
│   └── _Front_Cover_1773422703220.tiff
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection
├── scripts/                # Utility scripts
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── tsconfig.json
└── package.json
```

## Comic Reader Features

- **Landing page**: Cinematic cover display with title, author, "Start Reading" CTA, and PDF download
- **Reader**: Page-by-page vertical scroll, 140% zoomed comic images (crops white PDF margins), Previous/Next navigation
- **$15 Paywall**: Pages 1–5 are free; pages 6–18 require a one-time $15 Stripe Checkout purchase. Access token stored in localStorage and validated server-side via Bearer token
- **"To Be Continued" end page**: After the last comic page, a styled CTA screen links to the concept album and Patreon
- **Mobile landscape prompt**: Detects portrait orientation on mobile and prompts rotation
- **18 pages**: Pre-extracted from PDF as JPEG images (200 DPI)
- **PDF download**: Original 170MB PDF available for desktop users
- **Dark sci-fi theme**: Bebas Neue + Rajdhani fonts, orange/cyan accent colors, noise texture background

## API Endpoints

- `GET /api/comic/pages` — Comic metadata (title, author, page count, freePages, URLs)
- `GET /api/comic/page/:pageNumber` — Individual page image (JPEG, 1-indexed; pages >5 require `Authorization: Bearer <token>`)
- `GET /api/comic/cover` — Cover art image
- `GET /api/comic/download` — Full PDF download
- `POST /api/payment/create-checkout` — Creates a Stripe Checkout Session ($15), returns `{ checkoutUrl }`
- `GET /api/payment/verify?session_id=...` — Verifies payment, stores purchase, returns `{ accessToken }`
- `GET /api/payment/validate-token` — Validates Bearer token, returns `{ valid: boolean }`
- `GET /api/healthz` — Health check

## TypeScript & Composite Projects

Every package extends `tsconfig.base.json` which sets `composite: true`. The root `tsconfig.json` lists all packages as project references. This means:

- **Always typecheck from the root** — run `pnpm run typecheck`
- **`emitDeclarationOnly`** — we only emit `.d.ts` files during typecheck
- **Project references** — when package A depends on package B, A's `tsconfig.json` must list B in its `references` array

## Root Scripts

- `pnpm run build` — runs `typecheck` first, then recursively runs `build` in all packages
- `pnpm run typecheck` — runs `tsc --build --emitDeclarationOnly` using project references

## Packages

### `artifacts/api-server` (`@workspace/api-server`)

Express 5 API server with comic routes.

- Routes: `src/routes/comic.ts` — comic page images, metadata, cover, PDF download
- Routes: `src/routes/health.ts` — health check
- Static assets: `public/comic-pages/` (18 page images), `public/cover.jpg`
- Depends on: `@workspace/db`, `@workspace/api-zod`

### `artifacts/continuum-reader` (`@workspace/continuum-reader`)

React + Vite frontend for the comic reader.

- Pages: `src/pages/home.tsx` (landing/cover), `src/pages/reader.tsx` (comic reader)
- Components: `src/components/landscape-prompt.tsx`, `src/components/ui/sci-fi-button.tsx`
- Uses: Framer Motion (animations), Lucide React (icons), wouter (routing)
- Theme: Dark cinematic sci-fi with custom CSS variables

### `lib/api-spec` (`@workspace/api-spec`)

OpenAPI 3.1 spec with comic endpoints. Run codegen: `pnpm --filter @workspace/api-spec run codegen`

### `lib/api-zod` (`@workspace/api-zod`)

Generated Zod schemas (e.g. `GetComicPagesResponse`, `GetComicPageParams`).

### `lib/api-client-react` (`@workspace/api-client-react`)

Generated React Query hooks (e.g. `useGetComicPages`).

### `lib/db` (`@workspace/db`)

Database layer with Drizzle ORM. Schema: `purchases` table (id, stripe_session_id, amount_cents, access_token, created_at).

## Environment Variables

- `DATABASE_URL` — PostgreSQL connection string (Replit-managed)
- `STRIPE_SECRET_KEY` — Stripe API secret key (from Stripe integration)
- `STRIPE_PUBLISHABLE_KEY` — Stripe publishable key (from Stripe integration)
- `PORT` — Server port (Replit-managed)

### `scripts` (`@workspace/scripts`)

Utility scripts package.
