import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";

export const purchasesTable = pgTable("purchases", {
  id: serial("id").primaryKey(),
  stripeSessionId: text("stripe_session_id").notNull().unique(),
  amountCents: integer("amount_cents").notNull(),
  accessToken: text("access_token").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Purchase = typeof purchasesTable.$inferSelect;
