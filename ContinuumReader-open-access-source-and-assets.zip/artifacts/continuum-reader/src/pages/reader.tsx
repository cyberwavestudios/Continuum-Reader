import { useEffect, useState, useCallback, useRef } from "react";
import { Link, useRoute } from "wouter";
import { ChevronLeft, ChevronRight, Home, Loader2, Music, Heart, Globe } from "lucide-react";
import { useGetComicPages } from "@workspace/api-client-react";
import { SciFiButton } from "@/components/ui/sci-fi-button";
import { LandscapePrompt } from "@/components/landscape-prompt";
import { apiPaths, cn, getAccessToken, clearAccessToken } from "@/lib/utils";

const TOKEN_VALID_KEY = "continuum_token_valid_ts";
const TOKEN_TTL_MS = 10 * 60 * 1000;

function getCachedTokenValidity(): boolean | null {
  try {
    const raw = sessionStorage.getItem(TOKEN_VALID_KEY);
    if (!raw) return null;
    const ts = parseInt(raw, 10);
    if (Date.now() - ts < TOKEN_TTL_MS) return true;
    sessionStorage.removeItem(TOKEN_VALID_KEY);
  } catch {}
  return null;
}

function setCachedTokenValidity(): void {
  try {
    sessionStorage.setItem(TOKEN_VALID_KEY, String(Date.now()));
  } catch {}
}

function clearCachedTokenValidity(): void {
  try {
    sessionStorage.removeItem(TOKEN_VALID_KEY);
  } catch {}
}

const blobCache = new Map<number, string>();

function getCachedBlob(page: number): string | undefined {
  return blobCache.get(page);
}

function setCachedBlob(page: number, url: string): void {
  blobCache.set(page, url);
}

async function preloadPage(page: number, needsAuth: boolean): Promise<void> {
  // Only preload auth-gated pages via fetch+blob. Free pages use native <img>
  // which has its own caching — a competing fetch() would create two parallel
  // requests for the same resource on mobile, causing delays.
  if (!needsAuth) return;

  if (blobCache.has(page)) return;

  const token = getAccessToken();
  if (!token) return;

  const src = apiPaths.page(page);
  try {
    const res = await fetch(src, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) return;
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    setCachedBlob(page, url);
  } catch {}
}

function ToBeContinuedPage({ totalPages }: { totalPages: number }) {
  return (
    <div className="min-h-screen bg-black text-foreground flex flex-col">
      <LandscapePrompt />

      <header className="fixed top-0 left-0 right-0 z-40 p-3 pointer-events-none flex justify-between items-start">
        <Link href="/" className="pointer-events-auto focus:outline-none">
          <button
            className="w-9 h-9 rounded-full bg-black/40 backdrop-blur-sm border border-white/10 flex items-center justify-center text-white/50 hover:text-white/80 hover:bg-black/60 transition-all"
            aria-label="Back to Cover"
          >
            <Home className="w-4 h-4" />
          </button>
        </Link>

        <div className="pointer-events-auto bg-black/40 backdrop-blur-sm px-3 py-1 rounded-full border border-white/10 text-white/50 text-xs font-display tracking-widest">
          FIN
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center px-6 py-24">
        <div className="max-w-2xl w-full text-center space-y-10">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-7xl font-display tracking-wider text-foreground leading-tight">
              To Be Continued...
            </h1>
            <p className="text-xl md:text-2xl font-display tracking-widest text-primary">
              With The Blessing Of Your Support!
            </p>
          </div>

          <div className="w-24 h-px bg-gradient-to-r from-transparent via-primary to-transparent mx-auto" />

          <div className="space-y-4">
            <a
              href="https://continuum.cyberwavestudios.com"
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <SciFiButton variant="primary" size="xl" className="w-full h-20 md:h-24">
                <Music className="w-6 h-6 md:w-8 md:h-8 mr-3" />
                Listen to the Concept Album
              </SciFiButton>
            </a>

            <a
              href="https://threadseer.cyberwavestudios.com"
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <SciFiButton variant="outline" size="xl" className="w-full h-20 md:h-24">
                <Globe className="w-6 h-6 md:w-8 md:h-8 mr-3" />
                Explore the Extended Lore
              </SciFiButton>
            </a>

            <a
              href="https://www.patreon.com/CyberwaveResistanceNetwork?utm_campaign=creatorshare_creator"
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <SciFiButton variant="ghost" size="xl" className="w-full h-20 md:h-24 border border-white/10">
                <Heart className="w-6 h-6 md:w-8 md:h-8 mr-3" />
                Support on Patreon
              </SciFiButton>
            </a>
          </div>

          <div className="w-24 h-px bg-gradient-to-r from-transparent via-primary to-transparent mx-auto" />

          <p className="text-sm text-muted-foreground font-body tracking-wide">
            The story continues right where the last panel leaves off.
          </p>
        </div>
      </main>

      <Link href={`/read/${totalPages}`} className="fixed bottom-20 left-4 z-40 focus:outline-none -m-2 p-2">
        <button
          className="w-11 h-11 rounded-full bg-black/40 backdrop-blur-sm border border-white/10 flex items-center justify-center text-white/50 hover:text-white/80 hover:bg-black/60 transition-all"
          aria-label="Previous page"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      </Link>
    </div>
  );
}

export default function Reader() {
  const [, params] = useRoute("/read/:page?");
  const currentPage = parseInt(params?.page || "1", 10);

  const { data: metadata, isLoading: metadataLoading } = useGetComicPages();
  const totalPages = metadata?.totalPages || 18;
  const freePages = totalPages;

  const [tokenValid, setTokenValid] = useState<boolean | null>(null);

  const isEndPage = !isNaN(currentPage) && currentPage > totalPages;
  const isPaidPage = false;

  useEffect(() => {
    if (!isPaidPage) {
      setTokenValid(null);
      return;
    }
    const token = getAccessToken();
    if (!token) {
      setTokenValid(false);
      return;
    }

    const cached = getCachedTokenValidity();
    if (cached === true) {
      setTokenValid(true);
      return;
    }

    let cancelled = false;
    fetch(apiPaths.validateToken, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => r.json())
      .then((data) => {
        if (cancelled) return;
        if (data.valid === true) {
          setCachedTokenValidity();
          setTokenValid(true);
        } else {
          clearAccessToken();
          clearCachedTokenValidity();
          setTokenValid(false);
        }
      })
      .catch(() => {
        if (cancelled) return;
        setTokenValid(true);
      });

    return () => { cancelled = true; };
  }, [isPaidPage, currentPage]);

  const handleAccessGranted = useCallback(() => {
    setCachedTokenValidity();
    setTokenValid(true);
  }, []);


  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [atBottom, setAtBottom] = useState(false);
  const mainRef = useRef<HTMLElement>(null);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
    setImageLoaded(false);
    setImageError(false);
    setAtBottom(false);
  }, [currentPage]);

  useEffect(() => {
    const check = () => {
      if (!mainRef.current) return;
      const rect = mainRef.current.getBoundingClientRect();
      setAtBottom(rect.bottom <= window.innerHeight + 20);
    };
    check();
    window.addEventListener("scroll", check, { passive: true });
    window.addEventListener("resize", check, { passive: true });
    return () => {
      window.removeEventListener("scroll", check);
      window.removeEventListener("resize", check);
    };
  }, []);

  useEffect(() => {
    // Attempt to lock to landscape on browsers that support it (Android Chrome, etc).
    // Fails silently on iOS Safari — the LandscapePrompt banner serves as the fallback there.
    const lockOrientation = async () => {
      try {
        const orientation = screen.orientation as ScreenOrientation & {
          lock?: (mode: string) => Promise<void>;
        };
        await orientation.lock?.("landscape-primary");
      } catch {
        // Not supported or not allowed — ignore.
      }
    };
    lockOrientation();
    return () => {
      try { screen.orientation.unlock(); } catch { /* ignore */ }
    };
  }, []);

  useEffect(() => {
    if (!imageLoaded) return;
    if (isNaN(currentPage)) return;

    const nextPage = currentPage + 1;
    if (nextPage > totalPages) return;

    const needsAuth = nextPage > freePages;
    preloadPage(nextPage, needsAuth);
  }, [imageLoaded, currentPage, totalPages, freePages]);

  const validPage = !isNaN(currentPage) && currentPage >= 1 && currentPage <= totalPages;
  const hasNext = validPage && currentPage <= totalPages;
  const hasPrev = validPage && currentPage > 1;

  if (metadataLoading || (isPaidPage && tokenValid === null)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
      </div>
    );
  }

  if (isEndPage) {
    return <ToBeContinuedPage totalPages={totalPages} />;
  }

  if (!validPage) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-black text-foreground gap-6">
        <h1 className="text-4xl font-display">Page Not Found</h1>
        <p className="text-muted-foreground">Valid pages are 1 through {totalPages}.</p>
        <Link href="/">
          <SciFiButton variant="primary" size="lg">
            <Home className="w-5 h-5 mr-2" />
            Back to Cover
          </SciFiButton>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-foreground pb-4">
      <LandscapePrompt />

      <header className="fixed top-0 left-0 right-0 z-40 p-3 pointer-events-none flex justify-between items-start">
        <Link href="/" className="pointer-events-auto focus:outline-none">
          <button
            className="w-9 h-9 rounded-full bg-black/40 backdrop-blur-sm border border-white/10 flex items-center justify-center text-white/50 hover:text-white/80 hover:bg-black/60 transition-all"
            aria-label="Back to Cover"
          >
            <Home className="w-4 h-4" />
          </button>
        </Link>
        
        <div className="pointer-events-auto bg-black/40 backdrop-blur-sm px-3 py-1 rounded-full border border-white/10 text-white/50 text-xs font-display tracking-widest">
          {currentPage}/{totalPages}
        </div>
      </header>

      <main ref={mainRef} className="w-full flex justify-center relative min-h-screen overflow-x-hidden">
        {!imageLoaded && !imageError && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="flex flex-col items-center gap-4 text-primary">
              <Loader2 className="w-12 h-12 animate-spin" />
              <p className="font-display tracking-widest animate-pulse">DECRYPTING PAGE...</p>
            </div>
          </div>
        )}

        {imageError && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="flex flex-col items-center gap-4 text-center px-6">
              <p className="text-2xl font-display text-destructive">TRANSMISSION FAILED</p>
              <p className="text-muted-foreground">Could not load page {currentPage}.</p>
              <SciFiButton variant="outline" size="md" onClick={() => { setImageError(false); setImageLoaded(false); }}>
                Retry
              </SciFiButton>
            </div>
          </div>
        )}
        
        {!imageError && (
          <AuthenticatedImage
            key={currentPage}
            page={currentPage}
            src={apiPaths.page(currentPage)}
            alt={`Comic Page ${currentPage}`}
            needsAuth={currentPage > freePages}
            className={cn(
              "w-[140%] max-w-none h-auto object-contain transition-opacity duration-700",
              imageLoaded ? "opacity-100" : "opacity-0"
            )}
            onLoad={() => setImageLoaded(true)}
            onError={() => setImageError(true)}
          />
        )}
      </main>

      {hasPrev && (
        <div className="fixed bottom-20 left-4 z-40 flex items-center gap-2">
          <Link href={`/read/${currentPage - 1}`} className="focus:outline-none shrink-0 -m-2 p-2">
            <button
              className="w-11 h-11 rounded-full bg-black/40 backdrop-blur-sm border border-white/10 flex items-center justify-center text-white/50 hover:text-white/80 hover:bg-black/60 transition-all"
              aria-label="Previous page"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          </Link>
          <span
            className={cn(
              "font-display tracking-widest text-xs text-white/90 bg-black/50 backdrop-blur-sm px-2.5 py-1 rounded-full border border-white/20 transition-all duration-500 select-none pointer-events-none",
              atBottom && imageLoaded ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-2"
            )}
          >
            PREVIOUS
          </span>
        </div>
      )}

      {hasNext && (
        <div className="fixed bottom-20 right-4 z-40 flex items-center gap-2">
          <span
            className={cn(
              "font-display tracking-widest text-xs text-white/90 bg-black/50 backdrop-blur-sm px-2.5 py-1 rounded-full border border-white/20 transition-all duration-500 select-none pointer-events-none",
              atBottom && imageLoaded ? "opacity-100 translate-x-0" : "opacity-0 translate-x-2"
            )}
          >
            NEXT
          </span>
          <Link href={`/read/${currentPage + 1}`} className="focus:outline-none shrink-0 -m-2 p-2">
            <button
              className="w-11 h-11 rounded-full bg-black/40 backdrop-blur-sm border border-white/10 flex items-center justify-center text-white/50 hover:text-white/80 hover:bg-black/60 transition-all"
              aria-label="Next page"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </Link>
        </div>
      )}
    </div>
  );
}

function AuthenticatedImage({
  page,
  src,
  alt,
  needsAuth,
  className,
  onLoad,
  onError,
}: {
  page: number;
  src: string;
  alt: string;
  needsAuth: boolean;
  className?: string;
  onLoad?: () => void;
  onError?: () => void;
}) {
  const [blobUrl, setBlobUrl] = useState<string | null>(() => getCachedBlob(page) ?? null);
  const fetchedRef = useRef(false);

  useEffect(() => {
    if (!needsAuth) return;
    if (blobUrl) return;
    if (fetchedRef.current) return;
    fetchedRef.current = true;

    const token = getAccessToken();
    if (!token) {
      onError?.();
      return;
    }

    let cancelled = false;
    fetch(src, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => {
        if (!res.ok) throw new Error("Failed to load");
        return res.blob();
      })
      .then((blob) => {
        if (cancelled) return;
        const url = URL.createObjectURL(blob);
        setCachedBlob(page, url);
        setBlobUrl(url);
      })
      .catch(() => {
        if (!cancelled) onError?.();
      });

    return () => {
      cancelled = true;
    };
  }, [src, needsAuth, blobUrl, page]);

  if (!needsAuth) {
    return (
      <img
        src={src}
        alt={alt}
        className={className}
        onLoad={onLoad}
        onError={onError}
        style={{
          WebkitUserSelect: "none",
          userSelect: "none",
          WebkitTouchCallout: "none",
        }}
        draggable="false"
      />
    );
  }

  if (!blobUrl) return null;

  return (
    <img
      src={blobUrl}
      alt={alt}
      className={className}
      onLoad={onLoad}
      onError={onError}
      style={{
        WebkitUserSelect: "none",
        userSelect: "none",
        WebkitTouchCallout: "none",
      }}
      draggable="false"
    />
  );
}
