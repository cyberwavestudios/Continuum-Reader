import { motion } from "framer-motion";
import { Link } from "wouter";
import { CheckCircle2, BookOpen, ChevronRight } from "lucide-react";
import { SciFiButton } from "@/components/ui/sci-fi-button";

export default function OrderSuccess() {
  return (
    <div className="relative min-h-screen bg-[#030712] text-white flex flex-col items-center justify-center px-5">
      {/* Ambient glow */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-primary/8 blur-[140px]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
        className="relative z-10 max-w-md w-full text-center space-y-8"
      >
        {/* Icon */}
        <div className="flex justify-center">
          <div className="w-20 h-20 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center shadow-[0_0_40px_rgba(232,93,4,0.2)]">
            <CheckCircle2 className="w-9 h-9 text-primary" />
          </div>
        </div>

        {/* Copy */}
        <div className="space-y-3">
          <h1 className="font-display text-4xl tracking-wide">ORDER PLACED</h1>
          <p className="text-white/55 text-base leading-relaxed">
            Thank you for ordering the <span className="text-white/80 font-semibold">Continuum Infinity Set</span>.
            We'll ship your bundle within 5–10 business days. Keep an eye on your inbox for a confirmation.
          </p>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-4">
          <div className="h-px flex-1 bg-white/10" />
          <span className="text-[11px] font-display tracking-[0.2em] text-white/25 uppercase">While you wait</span>
          <div className="h-px flex-1 bg-white/10" />
        </div>

        {/* CTA back to reader */}
        <div className="space-y-3">
          <Link href="/read/1" className="block focus:outline-none">
            <SciFiButton size="lg" className="w-full shadow-[0_0_32px_rgba(232,93,4,0.2)]">
              <BookOpen className="w-5 h-5 mr-2" />
              Read the Digital Comic
              <ChevronRight className="w-5 h-5 ml-2" />
            </SciFiButton>
          </Link>

          <Link href="/" className="block">
            <button className="w-full py-3 text-sm text-white/35 hover:text-white/60 transition-colors font-display tracking-widest uppercase">
              Back to Cover
            </button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
