import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { BookOpen, Disc3, Globe, ChevronLeft, Package, Loader2, Star } from "lucide-react";
import { SciFiButton } from "@/components/ui/sci-fi-button";
import { apiPaths, cn } from "@/lib/utils";

const BUNDLE_PRICE = 24.99;
const SHIPPING = 4.80;
const TOTAL = BUNDLE_PRICE + SHIPPING;

const INCLUDES = [
  {
    icon: BookOpen,
    label: "Graphic Novel",
    detail: "Continuum Issue #1: Stay Alive or Die Trying — full print edition",
  },
  {
    icon: Disc3,
    label: "Concept Album",
    detail: '"We Never Met, But I Remember You" — original story soundtrack',
  },
  {
    icon: Globe,
    label: "Extended Lore App Ecosystem",
    detail: "Exclusive access code unlocking the full digital reader + hidden lore",
  },
];

export default function Order() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleOrder = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(apiPaths.createBundleCheckout, { method: "POST" });
      const data = await res.json();
      if (data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
      } else {
        setError("Something went wrong. Please try again.");
        setLoading(false);
      }
    } catch {
      setError("Could not reach the server. Please check your connection.");
      setLoading(false);
    }
  };

  const bundleImg = `${import.meta.env.BASE_URL}bundle.png`;

  return (
    <div className="relative min-h-screen bg-[#030712] text-white overflow-x-hidden">
      {/* Ambient glow backdrop */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -left-40 w-[600px] h-[600px] rounded-full bg-primary/5 blur-[120px]" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] rounded-full bg-cyan-500/5 blur-[100px]" />
      </div>

      {/* Back nav */}
      <header className="relative z-10 px-5 pt-5 pb-2">
        <Link href="/" className="inline-flex items-center gap-2 text-white/40 hover:text-white/70 transition-colors text-sm font-display tracking-widest group">
          <ChevronLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          BACK
        </Link>
      </header>

      <main className="relative z-10 max-w-5xl mx-auto px-5 md:px-10 py-8 md:py-14">
        {/* Hero: image + product info */}
        <div className="flex flex-col md:flex-row gap-10 md:gap-16 items-center md:items-start">

          {/* Product image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="w-full md:w-[45%] shrink-0"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-[0_0_80px_rgba(232,93,4,0.15)]">
              <img
                src={bundleImg}
                alt="Continuum Limited Edition Infinity Set — Graphic Novel and Concept Album"
                className="w-full h-auto object-cover"
              />
              {/* Subtle inner border glow */}
              <div className="absolute inset-0 rounded-2xl ring-1 ring-white/10 pointer-events-none" />
            </div>

            {/* Edition badge */}
            <div className="mt-4 flex items-center justify-center gap-2">
              <div className="h-px flex-1 bg-gradient-to-r from-transparent to-primary/40" />
              <span className="text-[10px] font-display tracking-[0.2em] text-primary/70 uppercase whitespace-nowrap">
                Limited Edition
              </span>
              <div className="h-px flex-1 bg-gradient-to-l from-transparent to-primary/40" />
            </div>
          </motion.div>

          {/* Product info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15, ease: "easeOut" }}
            className="flex-1 flex flex-col gap-7"
          >
            {/* Title block */}
            <div>
              <div className="inline-flex items-center gap-1.5 mb-4 px-3 py-1 rounded-full bg-primary/10 border border-primary/25 text-primary text-[11px] font-display tracking-[0.15em] uppercase">
                <Star className="w-3 h-3 fill-primary" />
                Physical Bundle
              </div>

              <h1 className="font-display text-4xl sm:text-5xl leading-tight tracking-wide text-white mb-2">
                CONTINUUM
              </h1>
              <h2 className="font-display text-xl sm:text-2xl text-primary tracking-widest mb-4">
                THE INFINITY SET
              </h2>
              <p className="text-white/55 text-sm leading-relaxed">
                Every piece of the Continuum universe in a single collector's package.
                Read it. Hear it. Explore it.
              </p>
            </div>

            {/* What's inside */}
            <div className="space-y-3">
              <p className="text-[11px] font-display tracking-[0.18em] text-white/35 uppercase">
                What's inside
              </p>
              {INCLUDES.map(({ icon: Icon, label, detail }) => (
                <div
                  key={label}
                  className="flex items-start gap-3 p-3.5 rounded-xl bg-white/[0.03] border border-white/[0.07]"
                >
                  <div className="mt-0.5 shrink-0 w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
                    <Icon className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white/90 mb-0.5">{label}</p>
                    <p className="text-xs text-white/45 leading-relaxed">{detail}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Pricing */}
            <div className="rounded-2xl bg-white/[0.03] border border-white/[0.08] p-5 space-y-2.5">
              <div className="flex justify-between items-center text-sm">
                <span className="text-white/50">Infinity Set Bundle</span>
                <span className="text-white/80 font-semibold">${BUNDLE_PRICE.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-white/50">Shipping & Handling</span>
                <span className="text-white/80 font-semibold">${SHIPPING.toFixed(2)}</span>
              </div>
              <div className="h-px bg-white/10 my-1" />
              <div className="flex justify-between items-center">
                <span className="font-display tracking-wider text-white/70 text-sm uppercase">Total</span>
                <span className="font-display text-2xl text-white tracking-wide">
                  ${TOTAL.toFixed(2)}
                </span>
              </div>
              <p className="text-[11px] text-white/30 text-right">
                Shipping address collected at checkout
              </p>
            </div>

            {/* CTA */}
            <div className="space-y-3">
              <button
                onClick={handleOrder}
                disabled={loading}
                className={cn(
                  "w-full flex items-center justify-center gap-3 py-4 px-8 rounded-xl font-display tracking-[0.12em] text-base uppercase transition-all duration-300",
                  "bg-primary hover:bg-primary/90 active:scale-[0.98] text-white shadow-[0_0_32px_rgba(232,93,4,0.35)] hover:shadow-[0_0_48px_rgba(232,93,4,0.5)]",
                  loading && "opacity-70 cursor-not-allowed"
                )}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Connecting to checkout…
                  </>
                ) : (
                  <>
                    <Package className="w-5 h-5" />
                    Order Now · ${TOTAL.toFixed(2)}
                  </>
                )}
              </button>

              {error && (
                <p className="text-center text-sm text-red-400/80">{error}</p>
              )}

              <p className="text-center text-[11px] text-white/25 leading-relaxed">
                Secure checkout via Stripe · Ships within 5–10 business days ·<br />
                By Cyberwave Studios
              </p>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
