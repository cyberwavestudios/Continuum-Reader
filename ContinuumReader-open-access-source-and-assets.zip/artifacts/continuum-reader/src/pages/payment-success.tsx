import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import { SciFiButton } from "@/components/ui/sci-fi-button";
import { apiPaths, setAccessToken } from "@/lib/utils";

export default function PaymentSuccess() {
  const [, navigate] = useLocation();
  const [status, setStatus] = useState<"verifying" | "success" | "error">("verifying");
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sessionId = params.get("session_id");

    if (!sessionId) {
      setStatus("error");
      setErrorMsg("No payment session found. Please try again.");
      return;
    }

    async function verify() {
      try {
        const res = await fetch(apiPaths.verifyPayment(sessionId!));
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          throw new Error(body.error || "Payment verification failed");
        }
        const { accessToken } = await res.json();
        setAccessToken(accessToken);
        setStatus("success");
        setTimeout(() => navigate("/read/6"), 2000);
      } catch (err: unknown) {
        setStatus("error");
        setErrorMsg(err instanceof Error ? err.message : "Something went wrong verifying your payment.");
      }
    }

    verify();
  }, [navigate]);

  return (
    <div className="min-h-screen bg-black text-foreground flex items-center justify-center px-6">
      <div className="max-w-md w-full text-center space-y-6">
        {status === "verifying" && (
          <>
            <Loader2 className="w-16 h-16 text-primary animate-spin mx-auto" />
            <h1 className="text-2xl md:text-3xl font-display tracking-wider">
              Verifying Payment...
            </h1>
            <p className="text-muted-foreground font-body">
              Confirming your purchase. Just a moment.
            </p>
          </>
        )}

        {status === "success" && (
          <>
            <CheckCircle className="w-16 h-16 text-green-400 mx-auto" />
            <h1 className="text-2xl md:text-3xl font-display tracking-wider text-green-400">
              Access Granted!
            </h1>
            <p className="text-muted-foreground font-body">
              Redirecting you to the comic...
            </p>
          </>
        )}

        {status === "error" && (
          <>
            <XCircle className="w-16 h-16 text-red-400 mx-auto" />
            <h1 className="text-2xl md:text-3xl font-display tracking-wider text-red-400">
              Verification Failed
            </h1>
            <p className="text-muted-foreground font-body">{errorMsg}</p>
            <SciFiButton variant="primary" size="lg" onClick={() => navigate("/read/6")}>
              Try Again
            </SciFiButton>
          </>
        )}
      </div>
    </div>
  );
}
