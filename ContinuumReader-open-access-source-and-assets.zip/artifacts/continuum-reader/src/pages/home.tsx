import { Link } from "wouter";
import { ChevronRight, BookOpen } from "lucide-react";
import { useGetComicPages } from "@workspace/api-client-react";
import { SciFiButton } from "@/components/ui/sci-fi-button";
import { apiPaths } from "@/lib/utils";
import { motion } from "framer-motion";

export default function Home() {
  const { data: metadata, isLoading } = useGetComicPages();

  return (
    <div className="relative min-h-screen flex flex-col overflow-hidden bg-background">
      {/* Background Cover Image with heavy cinematic overlays */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-40 animate-reveal"
        style={{ backgroundImage: `url(${apiPaths.cover})` }}
      />
      <div className="absolute inset-0 z-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
      <div className="absolute inset-0 z-0 bg-gradient-to-r from-background via-background/50 to-transparent" />

      {/* Main Content */}
      <main className="relative z-10 flex-1 flex flex-col justify-center px-6 md:px-16 lg:px-24 max-w-7xl mx-auto w-full py-12">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="max-w-2xl"
        >
          {/* Status Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-semibold tracking-wider uppercase mb-8">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            Issue #1 Available
          </div>

          <h1 className="text-6xl sm:text-8xl md:text-9xl font-display leading-[0.85] text-transparent bg-clip-text bg-gradient-to-b from-white to-white/60 mb-6 drop-shadow-lg">
            {metadata?.title || "CONTINUUM"}
          </h1>
          
          <h2 className="text-2xl sm:text-3xl text-primary font-display tracking-wide mb-4">
            {metadata?.subtitle || "Stay Alive or Die Trying"}
          </h2>
          
          <p className="text-xl text-muted-foreground mb-12">
            {metadata?.author || "by Charlie Hadley"}
          </p>

          <div className="flex flex-col items-stretch sm:items-start gap-4 w-full sm:w-auto">
            <Link href="/read/1" className="w-full sm:w-auto focus:outline-none">
              <SciFiButton size="xl" className="w-full sm:w-auto shadow-[0_0_40px_hsl(var(--primary)/0.25)]">
                Start Reading
                <ChevronRight className="w-6 h-6 ml-2" />
              </SciFiButton>
            </Link>

          </div>
        </motion.div>
      </main>

      {/* Footer Info */}
      <footer className="relative z-10 py-6 px-6 md:px-16 border-t border-border bg-background/50 backdrop-blur-sm flex items-center justify-between">
        <div className="flex items-center gap-3 text-muted-foreground">
          <BookOpen className="w-5 h-5" />
          <span className="font-semibold uppercase tracking-widest text-sm">
            {isLoading ? "Loading..." : `${metadata?.totalPages || 18} Pages`}
          </span>
        </div>
        <div className="text-xs text-muted-foreground/60 uppercase tracking-widest">
          Optimized for Mobile Landscape
        </div>
      </footer>
    </div>
  );
}
