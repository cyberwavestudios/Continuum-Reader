import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export const apiPaths = {
  cover: `${BASE}/api/comic/cover`,
  page: (num: number | string) => `${BASE}/api/comic/page/${num}`,
  download: `${BASE}/api/comic/download`,
  createCheckout: `${BASE}/api/payment/create-checkout`,
  verifyPayment: (sessionId: string) =>
    `${BASE}/api/payment/verify?session_id=${encodeURIComponent(sessionId)}`,
  validateToken: `${BASE}/api/payment/validate-token`,
  redeemCode: `${BASE}/api/payment/redeem-code`,
  createBundleCheckout: `${BASE}/api/payment/create-bundle-checkout`,
};

const ACCESS_TOKEN_KEY = "continuum_access_token";

export function getAccessToken(): string | null {
  try {
    return localStorage.getItem(ACCESS_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setAccessToken(token: string): void {
  try {
    localStorage.setItem(ACCESS_TOKEN_KEY, token);
  } catch {}
}

export function clearAccessToken(): void {
  try {
    localStorage.removeItem(ACCESS_TOKEN_KEY);
  } catch {}
}

export function hasAccessToken(): boolean {
  return getAccessToken() !== null;
}
