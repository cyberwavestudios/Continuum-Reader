import React from "react";
import { cn } from "@/lib/utils";

interface SciFiButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "outline" | "ghost";
  size?: "sm" | "md" | "lg" | "xl";
  asChild?: boolean;
}

export const SciFiButton = React.forwardRef<HTMLButtonElement, SciFiButtonProps>(
  ({ className, variant = "primary", size = "md", children, ...props }, ref) => {
    
    const variants = {
      primary: "bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-[0_0_20px_hsl(var(--primary)/0.4)] border border-transparent",
      secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 border border-border hover:border-primary/50",
      outline: "bg-transparent text-primary border border-primary/50 hover:bg-primary/10 hover:border-primary",
      ghost: "bg-transparent text-muted-foreground hover:text-foreground hover:bg-white/5 border border-transparent",
    };

    const sizes = {
      sm: "px-4 py-2 text-sm",
      md: "px-6 py-3 text-base",
      lg: "px-8 py-4 text-lg font-semibold",
      xl: "px-10 py-5 text-xl font-bold uppercase tracking-widest",
    };

    return (
      <button
        ref={ref}
        className={cn(
          "relative inline-flex items-center justify-center transition-all duration-300 ease-out clip-chamfer group focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2 focus:ring-offset-background disabled:opacity-50 disabled:pointer-events-none",
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      >
        {/* Subtle inner glow for primary buttons */}
        {variant === "primary" && (
          <span className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/10 to-white/0 opacity-0 group-hover:opacity-100 transition-opacity" />
        )}
        <span className="relative z-10 flex items-center gap-2">{children}</span>
      </button>
    );
  }
);

SciFiButton.displayName = "SciFiButton";
