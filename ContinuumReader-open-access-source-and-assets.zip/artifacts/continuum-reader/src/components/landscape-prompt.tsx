import { useEffect, useState } from "react";
import { RotateCcw, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export function LandscapePrompt() {
  const [showPrompt, setShowPrompt] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const checkOrientation = () => {
      const isMobile = window.innerWidth <= 850;
      const isPortrait = window.innerHeight > window.innerWidth;
      if (!isMobile || !isPortrait) {
        setDismissed(false);
      }
      setShowPrompt(isMobile && isPortrait);
    };

    checkOrientation();
    window.addEventListener("resize", checkOrientation);
    window.addEventListener("orientationchange", checkOrientation);
    return () => {
      window.removeEventListener("resize", checkOrientation);
      window.removeEventListener("orientationchange", checkOrientation);
    };
  }, []);

  return (
    <AnimatePresence>
      {showPrompt && !dismissed && (
        <motion.div
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="fixed bottom-20 left-3 right-3 z-50 flex items-center gap-3 px-4 py-3 rounded-xl bg-black/70 backdrop-blur-md border border-white/10 text-white/70 text-sm"
        >
          <RotateCcw className="w-4 h-4 shrink-0 text-primary" />
          <span className="flex-1 font-body tracking-wide">
            Rotate to landscape for the best experience
          </span>
          <button
            onClick={() => setDismissed(true)}
            className="shrink-0 w-11 h-11 flex items-center justify-center text-white/40 hover:text-white/70 transition-colors -mr-2"
            aria-label="Dismiss"
          >
            <X className="w-4 h-4" />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
