import { useState } from "react";
import { Link } from "wouter";
import { Lock, ChevronLeft, Home, Loader2, ShieldCheck, BookOpen, Music, Globe, KeyRound, Package } from "lucide-react";
import { SciFiButton } from "@/components/ui/sci-fi-button";
import { LandscapePrompt } from "@/components/landscape-prompt";
import { apiPaths, setAccessToken } from "@/lib/utils";
import teaserPanel from "@assets/12_1773584971020.jpeg";

interface PaywallProps {
  totalPages: number;
  freePages: number;
  onAccessGranted?: () => void;
}

export function Paywall({ totalPages, freePages, onAccessGranted }: PaywallProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showCodeEntry, setShowCodeEntry] = useState(false);
  const [code, setCode] = useState("");
  const [codeLoading, setCodeLoading] = useState(false);
  const [codeError, setCodeError] = useState<string | null>(null);

  async function handlePurchase() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(apiPaths.createCheckout, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || "Failed to start checkout");
      }
      const { checkoutUrl } = await res.json();
      if (checkoutUrl) {
        window.location.href = checkoutUrl;
      } else {
        throw new Error("No checkout URL returned");
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
      setLoading(false);
    }
  }

  async function handleRedeemCode() {
    if (!code.trim()) return;
    setCodeLoading(true);
    setCodeError(null);
    try {
      const res = await fetch(apiPaths.redeemCode, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: code.trim() }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || "Invalid code");
      }
      const { accessToken } = await res.json();
      setAccessToken(accessToken);
      if (onAccessGranted) {
        onAccessGranted();
      }
    } catch (err: unknown) {
      setCodeError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
      setCodeLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-black text-foreground flex flex-col">
      <LandscapePrompt />

      <header className="fixed top-0 left-0 right-0 z-40 p-4 bg-gradient-to-b from-black/80 to-transparent pointer-events-none flex justify-between items-start">
        <Link href="/" className="pointer-events-auto focus:outline-none">
          <SciFiButton variant="ghost" size="sm" className="bg-black/50 backdrop-blur-md text-white/80 hover:text-white border border-white/10 rounded-full clip-none px-4">
            <Home className="w-4 h-4 mr-2" />
            Back to Cover
          </SciFiButton>
        </Link>
      </header>

      <div className="relative w-full">
        <img
          src={teaserPanel}
          alt="A glimpse of what awaits..."
          className="w-full max-h-[50vh] object-cover object-top opacity-60"
          draggable="false"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black" />
      </div>

      <main className="flex-1 flex items-start justify-center px-6 pb-40 -mt-12 relative z-10">
        <div className="max-w-lg w-full text-center space-y-8">
          <div className="mx-auto w-20 h-20 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center">
            <Lock className="w-10 h-10 text-primary" />
          </div>

          <div className="space-y-3">
            <h1 className="text-3xl md:text-5xl font-display tracking-wider text-foreground leading-tight">
              You've Read the Preview
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground font-body">
              Pages {freePages + 1}–{totalPages} are waiting.
            </p>
          </div>

          <div className="w-24 h-px bg-gradient-to-r from-transparent via-primary to-transparent mx-auto" />

          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 space-y-5">
            <p className="text-sm uppercase tracking-widest text-primary font-display">
              One-Time Purchase
            </p>
            <div className="text-4xl md:text-5xl font-display tracking-wide text-foreground">
              $15
            </div>

            <div className="w-16 h-px bg-white/10 mx-auto" />

            <ul className="space-y-3 text-left">
              <li className="flex items-start gap-3">
                <BookOpen className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <span className="text-sm text-muted-foreground font-body">
                  <span className="text-foreground font-semibold">Pages {freePages + 1}–{totalPages}</span> of Issue #1: Stay Alive or Die Trying
                </span>
              </li>
              <li className="flex items-start gap-3">
                <Music className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <span className="text-sm text-muted-foreground font-body">
                  <span className="text-foreground font-semibold">Full-length sequel album</span> — the story continues through sound
                </span>
              </li>
              <li className="flex items-start gap-3">
                <Globe className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <span className="text-sm text-muted-foreground font-body">
                  <span className="text-foreground font-semibold">Threadseer</span> — interactive extended lore app
                </span>
              </li>
            </ul>
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-red-400 text-sm">
              {error}
            </div>
          )}

          <SciFiButton
            variant="primary"
            size="xl"
            className="w-full h-20 md:h-24"
            onClick={handlePurchase}
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="w-6 h-6 md:w-8 md:h-8 mr-3 animate-spin" />
                Connecting to Checkout...
              </>
            ) : (
              <>
                <ShieldCheck className="w-6 h-6 md:w-8 md:h-8 mr-3" />
                Unlock Everything — $15
              </>
            )}
          </SciFiButton>

          <Link href="/order" className="block w-full focus:outline-none">
            <SciFiButton
              variant="outline"
              size="lg"
              className="w-full border-white/15 text-white/60 hover:text-primary hover:border-primary/40 group"
            >
              <Package className="w-5 h-5 mr-2 group-hover:text-primary transition-colors" />
              Access the Physical Infinity Set
            </SciFiButton>
          </Link>

          <p className="text-xs text-muted-foreground/60 font-body flex items-center justify-center gap-1">
            <Lock className="w-3 h-3" />
            Secure checkout powered by Stripe
          </p>

          <div className="w-16 h-px bg-white/10 mx-auto" />

          <div className="space-y-4">
            <button
              type="button"
              onClick={() => setShowCodeEntry(!showCodeEntry)}
              className="text-sm text-muted-foreground/70 hover:text-primary transition-colors font-body flex items-center justify-center gap-2 mx-auto"
            >
              <KeyRound className="w-4 h-4" />
              {showCodeEntry ? "Hide code entry" : "Have a bundle or Patreon code?"}
            </button>

            {showCodeEntry && (
              <div className="bg-white/5 border border-white/10 rounded-xl p-4 space-y-3">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") handleRedeemCode(); }}
                    placeholder="Enter access code"
                    className="flex-1 bg-black/60 border border-white/20 rounded-lg px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/40 font-body focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/30"
                    disabled={codeLoading}
                  />
                  <SciFiButton
                    variant="secondary"
                    size="sm"
                    className="px-5 py-3 shrink-0"
                    onClick={handleRedeemCode}
                    disabled={codeLoading || !code.trim()}
                  >
                    {codeLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      "Redeem"
                    )}
                  </SciFiButton>
                </div>
                {codeError && (
                  <p className="text-red-400 text-sm font-body">{codeError}</p>
                )}
              </div>
            )}
          </div>
        </div>
      </main>

      <div className="fixed bottom-0 left-0 right-0 z-40 p-4 pb-6 md:pb-8 bg-gradient-to-t from-black via-black/90 to-transparent">
        <div className="max-w-4xl mx-auto flex items-center justify-center">
          <Link href={`/read/${freePages}`} className="flex-1 max-w-xs">
            <SciFiButton
              variant="secondary"
              size="lg"
              className="w-full h-16 md:h-20 text-lg md:text-xl"
            >
              <ChevronLeft className="w-8 h-8 md:w-10 md:h-10 mr-1 md:mr-2" />
              <span className="hidden sm:inline">Back to Page {freePages}</span>
              <span className="sm:hidden">Back</span>
            </SciFiButton>
          </Link>
        </div>
      </div>
    </div>
  );
}
