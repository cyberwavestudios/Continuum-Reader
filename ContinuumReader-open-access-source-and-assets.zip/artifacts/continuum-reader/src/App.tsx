import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import Home from "@/pages/home";
import Reader from "@/pages/reader";
import NotFound from "@/pages/not-found";

// Configure query client with smart defaults for the comic reader
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false, // Don't refetch metadata just because user switched tabs
      retry: 1,
      staleTime: 1000 * 60 * 60, // 1 hour stale time for metadata since it rarely changes
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/read/:page?" component={Reader} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Handle deployment subpaths securely
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={base}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
