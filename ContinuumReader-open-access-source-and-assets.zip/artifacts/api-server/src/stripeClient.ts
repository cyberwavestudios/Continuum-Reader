import Stripe from "stripe";

export function getUncachableStripeClient(): Stripe {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) {
    throw new Error(
      "STRIPE_SECRET_KEY is not set. " +
      "Ensure the Stripe integration is connected."
    );
  }
  return new Stripe(key);
}
