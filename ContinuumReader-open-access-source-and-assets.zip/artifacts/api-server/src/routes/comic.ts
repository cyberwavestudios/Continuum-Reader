import { Router, type IRouter } from "express";
import path from "path";
import fs from "fs";
import { GetComicPagesResponse, GetComicPageParams } from "@workspace/api-zod";
import { generateSampler, getSamplerPath } from "../samplerGenerator";

const router: IRouter = Router();

function findPackageRoot(): string {
  let dir = typeof __dirname !== "undefined" ? __dirname : process.cwd();
  while (dir !== path.dirname(dir)) {
    if (fs.existsSync(path.join(dir, "package.json"))) return dir;
    dir = path.dirname(dir);
  }
  return process.cwd();
}

const PACKAGE_ROOT = findPackageRoot();
const CACHE_DIR = path.resolve(PACKAGE_ROOT, "public", "comic-pages");
const PUBLIC_DIR = path.resolve(PACKAGE_ROOT, "public");
const COVER_CACHE_PATH = path.resolve(PACKAGE_ROOT, "public", "cover.jpg");

let extractedMetadata: { totalPages: number } | null = null;

function resolvePagePath(pageNum: number): string | null {
  const paddedNum = String(pageNum).padStart(2, "0");
  const paddedPath = path.join(CACHE_DIR, `page-${paddedNum}.jpg`);
  if (fs.existsSync(paddedPath)) return paddedPath;

  const unpaddedPath = path.join(CACHE_DIR, `page-${pageNum}.jpg`);
  if (fs.existsSync(unpaddedPath)) return unpaddedPath;

  return null;
}

function countCachedPages(): number {
  if (!fs.existsSync(CACHE_DIR)) return 0;
  const files = fs.readdirSync(CACHE_DIR);
  return files.filter((f) => /^page-\d+\.jpg$/.test(f)).length;
}

function validateCache(totalPages: number): boolean {
  for (let i = 1; i <= totalPages; i++) {
    if (!resolvePagePath(i)) return false;
  }
  return true;
}

function detectPages(): number {
  const cachedCount = countCachedPages();
  if (cachedCount > 0 && validateCache(cachedCount)) {
    console.log(`[comic] Cache hit: all ${cachedCount} page files present`);
    return cachedCount;
  }

  throw new Error(
    `No pre-extracted comic pages found in ${CACHE_DIR}. ` +
    `Expected page-01.jpg through page-NN.jpg files.`
  );
}

function detectCover() {
  if (fs.existsSync(COVER_CACHE_PATH)) {
    console.log("[comic] Cover cache hit");
    return;
  }

  console.warn(`[comic] Cover image not found at ${COVER_CACHE_PATH}`);
}

function getMetadata(): { totalPages: number } {
  if (extractedMetadata) return extractedMetadata;

  const totalPages = detectPages();
  detectCover();
  extractedMetadata = { totalPages };
  return extractedMetadata;
}

try {
  getMetadata();
  generateSampler(CACHE_DIR, PUBLIC_DIR).catch((err) => {
    console.error("[sampler] Background generation failed:", err);
  });
} catch (err) {
  console.error("[comic] Failed to extract on startup:", err);
}

router.get("/comic/pages", (_req, res) => {
  try {
    const meta = getMetadata();
    const data = GetComicPagesResponse.parse({
      title: "CONTINUUM",
      subtitle: "Issue #1: Stay Alive or Die Trying",
      author: "Charlie Hadley",
      totalPages: meta.totalPages,
      coverUrl: "/api/comic/cover",
      downloadUrl: "/api/comic/download",
    });
    res.json({ ...data, freePages: meta.totalPages });
  } catch (err) {
    res.status(500).json({ error: "Failed to load comic metadata" });
  }
});

router.get("/comic/page/:pageNumber", async (req, res) => {
  try {
    const parsed = GetComicPageParams.parse({ pageNumber: req.params.pageNumber });
    const pageNum = parsed.pageNumber;
    const meta = getMetadata();

    if (pageNum < 1 || pageNum > meta.totalPages) {
      res.status(404).json({ error: `Page ${pageNum} not found. Valid range: 1-${meta.totalPages}` });
      return;
    }

    const filePath = resolvePagePath(pageNum);

    if (!filePath) {
      res.status(404).json({ error: "Page image not found in cache" });
      return;
    }

    res.setHeader("Content-Type", "image/jpeg");
    res.setHeader("Cache-Control", "public, no-cache");
    fs.createReadStream(filePath).pipe(res);
  } catch (err) {
    res.status(400).json({ error: "Invalid page number" });
  }
});

router.get("/comic/cover", (_req, res) => {
  try {
    getMetadata();
  } catch (_) {}

  if (!fs.existsSync(COVER_CACHE_PATH)) {
    res.status(404).json({ error: "Cover image not found" });
    return;
  }

  res.setHeader("Content-Type", "image/jpeg");
  res.setHeader("Cache-Control", "public, max-age=86400");
  fs.createReadStream(COVER_CACHE_PATH).pipe(res);
});

router.get("/comic/download", async (_req, res) => {
  const samplerPath = getSamplerPath(PUBLIC_DIR);

  if (!fs.existsSync(samplerPath)) {
    try {
      await generateSampler(CACHE_DIR, PUBLIC_DIR);
    } catch (err) {
      console.error("[sampler] On-demand generation failed:", err);
      res.status(503).json({ error: "Sampler not ready yet, please try again shortly" });
      return;
    }
  }

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader(
    "Content-Disposition",
    'attachment; filename="Continuum_Issue1_Preview.pdf"',
  );
  res.setHeader("Cache-Control", "public, max-age=3600");
  fs.createReadStream(samplerPath).pipe(res);
});

export default router;
