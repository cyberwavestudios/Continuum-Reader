import { Router, type IRouter } from "express";
import { v4 as uuidv4 } from "uuid";
import crypto from "crypto";
import { db } from "@workspace/db";
import { purchasesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getUncachableStripeClient } from "../stripeClient";

const router: IRouter = Router();

const FREE_PAGES = 5;
const PRICE_CENTS = 1500;
const PRODUCT_NAME = "CONTINUUM Issue #1: Stay Alive or Die Trying";

function getErrorMessage(err: unknown): string {
  if (err instanceof Error) return err.message;
  return String(err);
}

function getBaseUrl(): string {
  if (process.env.REPLIT_DOMAINS) {
    return `https://${process.env.REPLIT_DOMAINS.split(",")[0]}`;
  }
  return `http://localhost:${process.env.PORT || 3000}`;
}

router.post("/payment/create-checkout", async (_req, res) => {
  try {
    const stripe = getUncachableStripeClient();
    const baseUrl = getBaseUrl();

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: PRODUCT_NAME,
              description: "Full digital comic access (pages 6–18)",
            },
            unit_amount: PRICE_CENTS,
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${baseUrl}/continuum-reader/payment/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${baseUrl}/continuum-reader/read/5`,
    });

    res.json({ checkoutUrl: session.url });
  } catch (err: unknown) {
    console.error("[payment] Failed to create checkout session:", getErrorMessage(err));
    res.status(500).json({ error: "Failed to create checkout session" });
  }
});

router.get("/payment/verify", async (req, res) => {
  try {
    const sessionId = req.query.session_id as string;
    if (!sessionId) {
      res.status(400).json({ error: "Missing session_id parameter" });
      return;
    }

    const existing = await db
      .select()
      .from(purchasesTable)
      .where(eq(purchasesTable.stripeSessionId, sessionId))
      .limit(1);

    if (existing.length > 0) {
      res.json({ accessToken: existing[0].accessToken, alreadyPurchased: true });
      return;
    }

    const stripe = getUncachableStripeClient();
    const session = await stripe.checkout.sessions.retrieve(sessionId, {
      expand: ["line_items"],
    });

    if (session.payment_status !== "paid") {
      res.status(402).json({ error: "Payment not completed" });
      return;
    }

    if (session.mode !== "payment") {
      res.status(400).json({ error: "Invalid session mode" });
      return;
    }

    if (
      session.amount_total !== PRICE_CENTS ||
      session.currency?.toLowerCase() !== "usd"
    ) {
      console.error(
        `[payment] Amount/currency mismatch: expected ${PRICE_CENTS} usd, got ${session.amount_total} ${session.currency}`
      );
      res.status(400).json({ error: "Payment amount mismatch" });
      return;
    }

    const lineItems = session.line_items?.data;
    if (
      !lineItems ||
      lineItems.length !== 1 ||
      lineItems[0].description !== PRODUCT_NAME
    ) {
      console.error("[payment] Line item mismatch for session:", sessionId);
      res.status(400).json({ error: "Invalid checkout item" });
      return;
    }

    const accessToken = uuidv4();

    await db.insert(purchasesTable).values({
      stripeSessionId: sessionId,
      amountCents: PRICE_CENTS,
      accessToken,
    });

    res.json({ accessToken, alreadyPurchased: false });
  } catch (err: unknown) {
    console.error("[payment] Failed to verify payment:", getErrorMessage(err));
    res.status(500).json({ error: "Failed to verify payment" });
  }
});

router.get("/payment/validate-token", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      res.status(401).json({ valid: false });
      return;
    }

    const token = authHeader.slice(7);
    const result = await db
      .select()
      .from(purchasesTable)
      .where(eq(purchasesTable.accessToken, token))
      .limit(1);

    res.json({ valid: result.length > 0 });
  } catch (err: unknown) {
    console.error("[payment] Token validation failed:", getErrorMessage(err));
    res.status(500).json({ valid: false });
  }
});

router.post("/payment/redeem-code", async (req, res) => {
  try {
    const { code } = req.body as { code?: string };
    if (!code || typeof code !== "string") {
      res.status(400).json({ error: "Missing access code" });
      return;
    }

    const expected = process.env.CONTINUUM_ACCESS_CODE;
    if (!expected) {
      console.error("[payment] CONTINUUM_ACCESS_CODE env var is not set");
      res.status(500).json({ error: "Code redemption is not configured" });
      return;
    }

    const codeHash = crypto.createHash("sha256").update(code).digest();
    const expectedHash = crypto.createHash("sha256").update(expected).digest();
    if (!crypto.timingSafeEqual(codeHash, expectedHash)) {
      res.status(401).json({ error: "Invalid access code" });
      return;
    }

    const accessToken = uuidv4();
    const syntheticSessionId = `code:${uuidv4()}`;

    await db.insert(purchasesTable).values({
      stripeSessionId: syntheticSessionId,
      amountCents: 0,
      accessToken,
    });

    res.json({ accessToken });
  } catch (err: unknown) {
    console.error("[payment] Code redemption failed:", getErrorMessage(err));
    res.status(500).json({ error: "Failed to redeem code" });
  }
});

const BUNDLE_PRODUCT_CENTS = 2499;
const BUNDLE_SHIPPING_CENTS = 480;
const BUNDLE_PRODUCT_NAME = "CONTINUUM: Limited Edition Infinity Set";

router.post("/payment/create-bundle-checkout", async (_req, res) => {
  try {
    const stripe = getUncachableStripeClient();
    const baseUrl = getBaseUrl();

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: BUNDLE_PRODUCT_NAME,
              description:
                'Graphic Novel (Issue #1) + Concept Album "We Never Met, But I Remember You" + Extended Lore App Ecosystem',
            },
            unit_amount: BUNDLE_PRODUCT_CENTS,
          },
          quantity: 1,
        },
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: "Shipping & Handling",
              description: "Standard shipping for physical items",
            },
            unit_amount: BUNDLE_SHIPPING_CENTS,
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      shipping_address_collection: {
        allowed_countries: [
          "US","CA","GB","AU","NZ","DE","FR","NL","SE","NO","DK","FI","IE","AT",
          "BE","CH","ES","IT","PT","PL","CZ","HU","RO","GR","MX","BR","JP","KR",
          "SG","HK","TW","ZA","AE","IN",
        ],
      },
      success_url: `${baseUrl}/continuum-reader/order/success`,
      cancel_url: `${baseUrl}/continuum-reader/order`,
    });

    res.json({ checkoutUrl: session.url });
  } catch (err: unknown) {
    console.error(
      "[payment] Failed to create bundle checkout session:",
      getErrorMessage(err)
    );
    res.status(500).json({ error: "Failed to create checkout session" });
  }
});

export { FREE_PAGES };
export default router;
