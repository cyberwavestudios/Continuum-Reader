import app from "./app";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const server = app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});

function shutdown(signal: string) {
  console.log(`[server] Received ${signal}, shutting down gracefully...`);
  server.close(() => {
    console.log("[server] Shutdown complete");
    process.exit(0);
  });

  setTimeout(() => {
    console.error("[server] Forced shutdown after timeout");
    process.exit(0);
  }, 10_000).unref();
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
