import path from "path";
import fs from "fs";
import PDFDocument from "pdfkit";

const FREE_PAGE_COUNT = 5;
const PAGE_WIDTH = 595;
const PAGE_HEIGHT = 770;
const SAMPLER_FILENAME = "sampler.pdf";

export function getSamplerPath(publicDir: string): string {
  return path.join(publicDir, SAMPLER_FILENAME);
}

export async function generateSampler(
  pagesDir: string,
  publicDir: string,
): Promise<string> {
  const outPath = getSamplerPath(publicDir);

  if (fs.existsSync(outPath)) {
    console.log("[sampler] Cache hit: sampler.pdf already exists");
    return outPath;
  }

  console.log("[sampler] Generating sampler PDF...");

  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      autoFirstPage: false,
      size: [PAGE_WIDTH, PAGE_HEIGHT],
      margin: 0,
      info: {
        Title: "CONTINUUM Issue #1 — Preview",
        Author: "Charlie Hadley",
        Subject: "Preview of CONTINUUM Issue #1: Stay Alive or Die Trying",
      },
    });

    const outStream = fs.createWriteStream(outPath);
    outStream.on("error", reject);
    outStream.on("finish", () => {
      console.log("[sampler] sampler.pdf generated successfully");
      resolve(outPath);
    });

    doc.pipe(outStream);

    for (let i = 1; i <= FREE_PAGE_COUNT; i++) {
      const paddedNum = String(i).padStart(2, "0");
      const imgPath = path.join(pagesDir, `page-${paddedNum}.jpg`);
      if (!fs.existsSync(imgPath)) {
        console.warn(`[sampler] Page image not found: ${imgPath}`);
        continue;
      }

      doc.addPage({ size: [PAGE_WIDTH, PAGE_HEIGHT], margin: 0 });
      doc.image(imgPath, 0, 0, { width: PAGE_WIDTH, height: PAGE_HEIGHT });
    }

    doc.addPage({ size: [PAGE_WIDTH, PAGE_HEIGHT], margin: 0 });
    _renderCtaPage(doc);

    doc.end();
  });
}

function _renderCtaPage(doc: InstanceType<typeof PDFDocument>): void {
  doc.rect(0, 0, PAGE_WIDTH, PAGE_HEIGHT).fill("#000000");

  const accentColor = "#D04A00";
  const textColor = "#FFFFFF";
  const mutedColor = "#888888";

  doc
    .rect(PAGE_WIDTH / 2 - 40, 90, 80, 2)
    .fill(accentColor);

  doc
    .fontSize(11)
    .fillColor(accentColor)
    .font("Helvetica-Bold")
    .text("CONTINUUM", 0, 68, {
      align: "center",
      characterSpacing: 8,
    });

  doc
    .fontSize(22)
    .fillColor(textColor)
    .font("Helvetica-Bold")
    .text("You've read the preview.", 0, 120, {
      align: "center",
      characterSpacing: 1,
    });

  doc
    .fontSize(13)
    .fillColor(mutedColor)
    .font("Helvetica")
    .text("Issue #1: Stay Alive or Die Trying", 0, 158, {
      align: "center",
      characterSpacing: 1,
    });

  doc
    .rect(PAGE_WIDTH / 2 - 40, 190, 80, 1)
    .fill("#333333");

  doc
    .fontSize(12)
    .fillColor(mutedColor)
    .font("Helvetica")
    .text("The full story — all 18 pages — is available now.", 40, 218, {
      align: "center",
      width: PAGE_WIDTH - 80,
    });

  doc
    .fontSize(12)
    .fillColor(mutedColor)
    .font("Helvetica")
    .text(
      "Get the physical comic bundle at:",
      40,
      244,
      { align: "center", width: PAGE_WIDTH - 80 },
    );

  const btnX = PAGE_WIDTH / 2 - 130;
  const btnY = 282;
  const btnW = 260;
  const btnH = 46;

  doc
    .roundedRect(btnX, btnY, btnW, btnH, 4)
    .fill(accentColor);

  doc
    .fontSize(13)
    .fillColor(textColor)
    .font("Helvetica-Bold")
    .text("cyberwavestudios.com", btnX, btnY + 15, {
      width: btnW,
      align: "center",
      characterSpacing: 0.5,
      link: "https://cyberwavestudios.com",
    });

  doc
    .rect(PAGE_WIDTH / 2 - 40, 360, 80, 1)
    .fill("#222222");

  doc
    .fontSize(11)
    .fillColor(mutedColor)
    .font("Helvetica")
    .text(
      "The bundle includes the physical comic,\nthe full-length sequel album, and access to Threadseer —\nthe interactive extended lore app.",
      40,
      378,
      {
        align: "center",
        width: PAGE_WIDTH - 80,
        lineGap: 4,
      },
    );

  doc
    .fontSize(10)
    .fillColor("#444444")
    .font("Helvetica")
    .text(
      "Or read the full digital issue at cyberwavestudios.com",
      40,
      PAGE_HEIGHT - 50,
      { align: "center", width: PAGE_WIDTH - 80 },
    );
}
